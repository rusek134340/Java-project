public class Book extends Product {
    public BookTypes bType;

    public Book(String name, double price) throws CustomException {
        super(name, price);
        if (price < 0) {
            throw new CustomException("Price cannot be negative number!");
        }
    }

    public enum BookTypes {
        HORROR, THRILLER, ROMANCE,
    }

    @Override
    public String toString() {
        return getName() + " " + getPrice() + " " + bType;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Book book = (Book) obj;
        return getName().equals(book.getName());
    }

    @Override
    public int hashCode() {
        return getName().hashCode();
    }
}