public class EBook extends Book{
    public EBook(String name, double price) throws CustomException{
        super (name, price);
    }

    public String toString(){
        return getName() + " " + getPrice() + " " + bType;
    }
}
