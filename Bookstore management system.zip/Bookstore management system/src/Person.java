public abstract class Person {
    private String name;
    private String email;
    private int loyaltyPoints;

    public Person(String name, String email){
        this.name = name;
        this.email = email;
        this.loyaltyPoints = 0;
    }

    public String getName(){
        return name;
    }
    public String getEmail(){
        return email;
    }
    public int getLoyaltyPoints(){
        return loyaltyPoints;
    }

    public void addPoints(double payedAmount) {
        int points = (int) payedAmount;
        loyaltyPoints += points;
        System.out.println("You earned " + points + " points! Your loyalty points total is: " + loyaltyPoints);
    }
}
