import java.util.Arrays;

public class Supplies {
    private Product[] products = new Product[50];
    private int productCount = 0;

    public void addProduct(Product product) {
        if (productCount < products.length) {
            products[productCount++] = product;
        }
    }

    public Product findProductByName(String name) {
        for (int i = 0; i < productCount; i++) {
            if (products[i].getName().equalsIgnoreCase(name)) {
                return products[i];
            }
        }
        return null;
    }

    public Product[] getProducts() {
        return Arrays.copyOf(products, productCount);
    }

    public void displayAllProducts() {
        System.out.println("Available Products:");
        for (int i = 0; i < productCount; i++) {
            System.out.println(products[i]);
        }
    }
}
