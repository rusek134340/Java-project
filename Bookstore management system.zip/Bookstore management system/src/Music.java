public class Music extends Product{
    public MusicGenre mGenre;

    public Music(String name, double price){
        super (name, price);
    }

    public enum MusicGenre{
        POP, RAP, METAL
    }

    @Override
    public String toString() {
        return getName() + " " + getPrice() + " " + mGenre;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Music music = (Music) obj;
        return getName().equals(music.getName());
    }

    @Override
    public int hashCode() {
        return getName().hashCode();
    }
}
