import java.util.Arrays;
import java.util.Scanner;

public class BookstoreManagementSystem {
    private static Supplies supplies = new Supplies();
    private static Product[] cart = new Product[50];
    private static int cartSize = 0;
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) throws CustomException {
        initializeProducts();

        while (true) {
            System.out.println("\n=== Bookstore ===");
            System.out.println("1. Products");
            System.out.println("2. Add to cart");
            System.out.println("3. Cart & Checkout");
            System.out.println("4. Exit");
            System.out.print("Choose an option (1-4): ");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    browseProducts();
                    break;
                case 2:
                    addToCart();
                    break;
                case 3:
                    checkout();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid option!");
            }
        }
    }

    private static void initializeProducts() throws CustomException {
        Book book1 = new Book("The Shining", 20.99);
        book1.bType = Book.BookTypes.HORROR;
        supplies.addProduct(book1);
        Book book2 = new Book("The Silence of the Lambs", 30.99);
        book2.bType = Book.BookTypes.THRILLER;
        supplies.addProduct(book2);
        Book book3 = new Book("Happy Place", 29.99);
        book3.bType = Book.BookTypes.ROMANCE;
        supplies.addProduct(book3);

        EBook ebook = new EBook("Gone Girl", 10.99);
        ebook.bType = Book.BookTypes.THRILLER;
        supplies.addProduct(ebook);

        Music music1 = new Music("Thriller", 19.99);
        music1.mGenre = Music.MusicGenre.POP;
        supplies.addProduct(music1);
        Music music2 = new Music("Chromakopia", 30.00);
        music2.mGenre = Music.MusicGenre.RAP;
        supplies.addProduct(music2);
        Music music3 = new Music("Meliora", 25.99);
        music3.mGenre = Music.MusicGenre.METAL;
        supplies.addProduct(music3);

        Games games1 = new Games("UNO", 25.99);
        games1.gType = Games.GameType.CARDGAME;
        supplies.addProduct(games1);
        Games games2 = new Games("Monopoly", 30.99);
        games2.gType = Games.GameType.BOARDGAME;
        supplies.addProduct(games2);
        Games games3 = new Games("The Witcher", 40.00);
        games3.gType = Games.GameType.VIDEOGAME;
        supplies.addProduct(games3);

        Stationery stationery1 = new Stationery("Pink Notebook", 12.99);
        stationery1.sType = Stationery.StationeryTypes.NOTEBOOK;
        supplies.addProduct(stationery1);
        Stationery stationery2 = new Stationery("BiC pen", 5.99);
        stationery2.sType = Stationery.StationeryTypes.PEN;
        supplies.addProduct(stationery2);
        Stationery stationery3 = new Stationery("Colorfull stickynotes", 10.00);
        stationery3.sType = Stationery.StationeryTypes.STICKYNOTES;
        supplies.addProduct(stationery3);
        }


    private static void browseProducts() {
        System.out.println("\n--- Available Products ---");
        for (Product product : supplies.getProducts()) {
            if (product != null) {
            System.out.println(product);
            }
        }
    }

    private static void addToCart() {
        System.out.print("Enter product name to add: ");
        String name = scanner.nextLine();

        Product product = supplies.findProductByName(name);
        if (product != null) {
            cart[cartSize++] = product;
            System.out.println("Added to cart: " + product.getName());
        } else {
            System.out.println("Product not found!");
        }
    }

    private static void checkout() {
        System.out.println("\n--- Checkout ---");
        System.out.print("Enter customer name: ");
        String name = scanner.nextLine();

        System.out.print("Enter payment method (CASH/CARD): ");
        String paymentMethod = scanner.nextLine();

        Customer customer = new Customer(name, "example.email@wompwomp.com");
        Order order = new Order(customer);

        for (int i = 0; i < cartSize; i++) {
            if (cart[i] != null) {
                order.addProduct(cart[i]);
            }
        }

        Payment payment = new Payment(order.calculateTotal(), paymentMethod);
        order.setPayment(payment);

        System.out.println("Order summary:");
        for (int i = 0; i < cartSize; i++) {
            if (cart[i] != null) {
                System.out.println("- " + cart[i].getName() + ": " + cart[i].getPrice() + " zł");
            }
        }
        System.out.println("Total: " + order.calculateTotal() + " zł");

        order.completeOrder();
        Arrays.fill(cart, null);
        cartSize = 0;
    }
}