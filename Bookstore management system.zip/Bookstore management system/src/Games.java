public class Games extends Product {
    public GameType gType;

    public Games(String name, double price){
        super (name, price);
    }

    public enum GameType{
        CARDGAME, BOARDGAME, VIDEOGAME
    }

    @Override
    public String toString() {
        return getName() + " " + getPrice() + " " + gType;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Games game = (Games) obj;
        return getName().equals(game.getName());
    }

    @Override
    public int hashCode() {
        return getName().hashCode();
    }
}
