public class Stationery extends Product{
    public StationeryTypes sType;

    public Stationery(String name, double price){
        super (name, price);
    }

    public enum StationeryTypes{
        NOTEBOOK, STICKYNOTES, PEN
    }

    @Override
    public String toString() {
        return getName() + " " + getPrice() + " " + sType;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Stationery stationery = (Stationery) obj;
        return getName().equals(stationery.getName());
    }

    @Override
    public int hashCode() {
        return getName().hashCode();
    }
}
