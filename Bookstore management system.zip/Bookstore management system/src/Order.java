public class Order {
    private Product[] products = new Product[50];
    private int productCount = 0;
    private Customer customer;
    private Payment payment;

    public Order(Customer customer){
        this.customer = customer;
    }

    public void addProduct(Product product) {
        if (productCount < products.length) {
            products[productCount++] = product;
        }
    }

    public double calculateTotal() {
        double total = 0;
        for (int i = 0; i < productCount; i++) {
            total += products[i].getPrice();
        }
        return total;
    }

    public void setPayment(Payment payment){

        this.payment = payment;
    }

    public void completeOrder() {
        double total = calculateTotal();
        System.out.println("Order completed for " + customer.getName());
        System.out.println("Total: " + total + " zł");
        payment.process();
        customer.addPoints(total);
    }

    @Override
    public String toString() {
        return "Order for " + customer.getName() + " with " + productCount + " items";
    }
}
