public class Payment {
    private double amount;
    private String method;

    public Payment(double amount, String method){
        this.amount = amount;
        this.method = method;
    }
    public void process(){
        System.out.println( amount + "zł payed, payment method: " + method);
    }

    @Override
    public String toString(){
        return method + " payment: " + amount + " zł";
    }
}